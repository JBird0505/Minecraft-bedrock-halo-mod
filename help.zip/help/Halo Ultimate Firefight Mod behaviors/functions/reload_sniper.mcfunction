playsound item.crossbow.loading_start @s
cooldown @s sniper_reload 60
scoreboard players set @s ammo 4
playsound item.crossbow.loading_end @s
title @s actionbar {"text":"Ammo: ","color":"white","extra":[{"score":{"name":"@s","objective":"ammo"}}]}
scoreboard objectives add ammo dummy
scoreboard players set @s ammo 4